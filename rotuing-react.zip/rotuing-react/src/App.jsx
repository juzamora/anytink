import { Route, BrowserRouter as Router, Routes } from 'react-router-dom';
import './App.css';
import Building from './screens/Building';
import Home from './screens/Home';

function App() {

  return (
    <Router>
      <Routes>
        <Route path='/home' exact element={<Home />} />
        <Route path='/building' exact element={<Building />} />
      </Routes>
    </Router>
  );
}

export default App

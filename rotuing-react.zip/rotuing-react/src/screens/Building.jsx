import { React, useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';


export default function Building() {

  //Consumir una api
  const url = "https://jsonplaceholder.typicode.com/todos";
  const [todos, setTodos] = useState()
  const fetchApi = async () => {
    const response = await fetch(url);
    console.log(response.status)
    const responseJSON = await  response.json();
    setTodos(responseJSON)

  }
//Nos permite engancharnos del cilco d evida del componentes
//Con esto se ejecuta al iniciar la aplicacion una unica vezs
  useEffect(() => {
   fetchApi()
  }, [])
  


  const navigate = useNavigate();
  return (
    <div>
      <div>Building</div>
      <button onClick={() => navigate("/home")}>Home</button>

      <ul>
        {!todos ? "Cargando..." : todos.map((todo,index) => {return <li key={index}>{todo.title}</li>})}
        
      </ul>
    </div>
  );
}

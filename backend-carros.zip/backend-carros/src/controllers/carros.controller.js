import { getConnection } from '../database/database.js';

//Metodo GET - Lectura datos
const getCarros = async (req, res) => {

  try {
    const connection = await getConnection();
    const result = await connection.query('SELECT id, marca, modelo, año, color FROM referencias_carro');
    res.json(result[0]);

    
  } catch (error) {
    res.status(500);
    res.send(error.message)
  }
  // res.send('Hello World');
};


//Crear carro
const createCarro = async (req, res) => {
  try {
    const {marca, modelo, año, color} = req.body;
    const dataToInput = {marca, modelo, año, color};
    console.log(marca, modelo, año, color);
    const connection = await getConnection();
    const result = await connection.query('INSERT INTO referencias_carro SET ?', [dataToInput]);
    res.json(result);
    res.json({message: 'Carro creado'});
  } catch (error) {
    
  }
}
export const methodsCarros = {
  getCarros,
  createCarro,
};
import { Router } from "express";
import { methodsCarros as carrosController } from '../controllers/carros.controller.js';

const router = Router();

router.get('/api/carros', carrosController.getCarros);
router.post('/api/create-carro', carrosController.createCarro);

export default router;